const listaTareas = document.getElementById(`listaTareas`)
const tareaInput = document.getElementById(`tareaInput`)

function agregarTarea() 
{
 const tareaTexto= tareaInput.value.trim();
 const tarea = {
    id: Date.now(),
    texto: tareaTexto
 }   

    const tareaItem = document.createElement('li');
    tareaItem.className = "tarea-item";
    tareaItem.id = tarea.id;

    const tareaSpan= document.createElement('span')
    tareaSpan.textContent = tarea.texto;

    tareaItem.appendChild(tareaSpan)

    listaTareas.appendChild(tareaItem)
    guardarTareas()
 
}

function guardarTareas() 
{
 
    const tareas = [];
    document.querySelectorAll('.tarea-item')

    document.querySelectorAll('.tarea-item').forEach(
    item => {
        const tarea = {
            id: Number(item.dataset.id),
            texto: item.querySelector('span').textContent
        }
        tareas.push(tarea);
    }

    )
    
    localStorage.setItem('tares', JSON.stringify(tareas))
    console.log(localStorage);
    
}